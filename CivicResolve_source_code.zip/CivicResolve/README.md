# CivicResolve - Python Backend

A starter backend for a civic-issues reporting hackathon project. It supports:
- Submitting complaints about potholes, garbage, water supply, streetlights, drainage, or other issues
- Selecting English, Telugu, Hindi, or Other as the report language
- Listing complaints and tracking a complaint by ID
- Updating complaint status
- Storing reports in a local SQLite database

## Requirements
- Python 3.6
- pip

## Run on Ubuntu

```bash
python3 --version
python3 -m pip install -r requirements.txt
python3 app.py
```

If `pip` is missing, install it with your Ubuntu package manager or ask your lab administrator for help.

Open this URL in a browser after starting the server:

`http://127.0.0.1:5000/`

## API examples

### Submit a complaint
Send a `POST` request to `http://127.0.0.1:5000/complaints` with JSON:

```json
{
  "name": "Demo User",
  "category": "Pothole",
  "description": "There is a pothole near the bus stop.",
  "location": "Main road near bus stop",
  "language": "English"
}
```

### List all complaints
`GET http://127.0.0.1:5000/complaints`

### Track one complaint
`GET http://127.0.0.1:5000/complaints/1`

### Update a complaint status
Send a `PATCH` request to `http://127.0.0.1:5000/complaints/1/status` with JSON:

```json
{"status": "In Progress"}
```

Allowed statuses: `Submitted`, `In Progress`, `Resolved`.

## Important notes
- This is a starter backend, not a complete deployed website.
- Voice recording/speech-to-text needs a frontend or speech-recognition integration; this backend accepts the resulting text in the `description` field.
- The language field records the selected language; automatic translation is not implemented yet.
- The local SQLite database file `complaints.db` is created when you run the app. Do not upload real personal complaint data to GitHub.
- The Flask development server is for local testing only, not production deployment.
